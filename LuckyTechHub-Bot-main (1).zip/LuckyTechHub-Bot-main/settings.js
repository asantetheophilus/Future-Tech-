const settings = {
  packname: 'Lucky Tech Hub Bot',
  author: '‎',
  botName: "Lucky Tech Hub Bot",
  botOwner: 'Lucky218', // Your name
  ownerNumber: '256789101112', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.8",
};

module.exports = settings;
